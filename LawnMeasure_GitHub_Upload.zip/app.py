"""LawnMeasure — US aerial-imagery lawn ESTIMATOR.

No paid API keys. Uses US Census address geocoding and USGS NAIP imagery.
Automatically uses Boone County, KY parcel polygons if an address match is found.
Classification is a color/texture heuristic, NOT a trained lawn segmentation model.
"""
from __future__ import annotations

import base64
import io
import json
import math
import re
from difflib import SequenceMatcher
from functools import lru_cache

import numpy as np
import requests
from flask import Flask, jsonify, request, send_from_directory
from PIL import Image, ImageDraw
from scipy.ndimage import binary_closing, binary_opening, uniform_filter
from shapely.geometry import Point, Polygon, shape, mapping
from shapely.ops import transform

app = Flask(__name__, static_folder="static")
app.json.sort_keys = False

CENSUS = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress"
NAIP = "https://imagery.nationalmap.gov/arcgis/rest/services/USGSNAIPImagery/ImageServer/exportImage"
BOONE_PARCELS = "https://secure.boonecountygis.com/server/rest/services/ParcelLayers/MapServer/32/query"
PIXELS = 768
METERS_TO_FEET2 = 10.76391041671
MERC_R = 6378137.0
HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "LawnMeasure-Demo/1.0 (address-based imagery estimator)"})


class DataUnavailable(Exception):
    pass


def get_json(url: str, params: dict) -> dict:
    try:
        r = HTTP.get(url, params=params, timeout=26)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("error"):
            raise DataUnavailable(str(data["error"].get("message", "Remote service error")))
        return data
    except (requests.RequestException, ValueError) as exc:
        raise DataUnavailable("A mapping provider could not complete the request. Please try again.") from exc


@lru_cache(maxsize=128)
def geocode(address: str) -> dict:
    response = get_json(CENSUS, {"address": address, "benchmark": "Public_AR_Current", "format": "json"})
    matches = response.get("result", {}).get("addressMatches", [])
    if not matches:
        raise ValueError("Address not found. Enter a complete U.S. street address including city and state.")
    item = matches[0]
    return {"lon": float(item["coordinates"]["x"]), "lat": float(item["coordinates"]["y"]),
            "label": item.get("matchedAddress", address),
            "state": item.get("addressComponents", {}).get("state", "")}


def merc_x(lon: float) -> float:
    return math.radians(lon) * MERC_R


def merc_y(lat: float) -> float:
    lat = max(-85.05, min(85.05, lat))
    return MERC_R * math.log(math.tan(math.pi / 4 + math.radians(lat) / 2))


def inv_x(x: float) -> float:
    return math.degrees(x / MERC_R)


def inv_y(y: float) -> float:
    return math.degrees(2 * math.atan(math.exp(y / MERC_R)) - math.pi / 2)


def normalize_street(s: str) -> str:
    s = re.sub(r"[^A-Z0-9 ]", " ", s.upper()).strip()
    s = re.sub(r"\s+", " ", s)
    substitutions = {"STREET": "ST", "ROAD": "RD", "AVENUE": "AVE", "DRIVE": "DR", "LANE": "LN",
                     "COURT": "CT", "BOULEVARD": "BLVD", "PLACE": "PL", "PARKWAY": "PKWY",
                     "CIRCLE": "CIR", "HIGHWAY": "HWY", "NORTH": "N", "SOUTH": "S",
                     "EAST": "E", "WEST": "W"}
    return " ".join(substitutions.get(t, t) for t in s.split())


def query_boone_parcel(address: str, lon: float, lat: float):
    """Only return parcel when site address matches; never silently pick a neighbor."""
    if not (-85.0 < lon < -84.45 and 38.75 < lat < 39.25):
        return None
    street = normalize_street(address.split(",")[0])
    match = re.match(r"^(\d+[A-Z]?)\s+(.+)$", street)
    if not match:
        return None
    house, street_name = match.groups()
    # Match a short prefix in case county and Census abbreviations differ.
    search_tokens = street_name.split()
    prefix = " ".join(search_tokens[:min(2, len(search_tokens))])
    params = {"where": f"SITEADD1 LIKE '{house} {prefix.replace(chr(39), chr(39)*2)}%'",
              "outFields": "SITEADD1,PIDN", "outSR": 4326, "returnGeometry": "true",
              "resultRecordCount": 100, "f": "geojson"}
    try:
        results = get_json(BOONE_PARCELS, params).get("features", [])
    except (DataUnavailable, AttributeError):
        return None
    candidates = []
    for f in results:
        try:
            site = normalize_street(str(f.get("properties", {}).get("SITEADD1") or ""))
            if not site or site.split()[0] != house:
                continue
            # Comparing normalized street labels avoids unverified selection.
            score = SequenceMatcher(None, street, site).ratio()
            if score < 0.80:
                continue
            poly = shape(f["geometry"])
            if not poly.is_valid:
                poly = poly.buffer(0)
            if poly.is_empty or poly.geom_type not in ("Polygon", "MultiPolygon"):
                continue
            nearby_m = poly.distance(Point(lon, lat)) * 111000
            if nearby_m > 500:  # Census estimates can be offset from a lot.
                continue
            candidates.append((score - nearby_m / 100000, poly, site))
        except (TypeError, ValueError, KeyError, IndexError):
            continue
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def bounds_for(geom, lat: float, lon: float, radius: int):
    """Return square Web Mercator bbox, with scale adjusted for latitude."""
    coslat = max(math.cos(math.radians(lat)), 0.1)
    if geom is not None:
        mapped = transform(lambda x, y, z=None: (np.radians(x) * MERC_R,
                          MERC_R * np.log(np.tan(np.pi / 4 + np.radians(np.clip(y, -85, 85)) / 2))), geom)
        xmin, ymin, xmax, ymax = mapped.bounds
        ground_side = max((xmax - xmin) * coslat, (ymax - ymin) * coslat)
        side = max(ground_side * 1.16 + 15, 85) / coslat
        cx, cy = (xmin + xmax) / 2, (ymin + ymax) / 2
    else:
        side = max(radius * 2.7, 95) / coslat
        cx, cy = merc_x(lon), merc_y(lat)
    return cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2


def export_naip(bbox: tuple, raster_function: str | None) -> Image.Image:
    xmin, ymin, xmax, ymax = bbox
    params = {"bbox": f"{xmin},{ymin},{xmax},{ymax}", "bboxSR": 3857,
              "imageSR": 3857, "size": f"{PIXELS},{PIXELS}",
              "format": "jpg", "interpolation": "RSP_NearestNeighbor", "f": "image"}
    if raster_function:
        params["renderingRule"] = json.dumps({"rasterFunction": raster_function})
    try:
        response = HTTP.get(NAIP, params=params, timeout=50)
        response.raise_for_status()
        if not response.headers.get("content-type", "").lower().startswith("image/"):
            raise DataUnavailable("Aerial imagery was unavailable for this location.")
        return Image.open(io.BytesIO(response.content)).convert("RGB")
    except (requests.RequestException, ValueError, OSError) as exc:
        raise DataUnavailable("USGS aerial imagery is unavailable right now or this address is outside coverage.") from exc


def geometry_mask(geom, bbox: tuple) -> np.ndarray:
    canvas = Image.new("L", (PIXELS, PIXELS), 0)
    painter = ImageDraw.Draw(canvas)
    xmin, ymin, xmax, ymax = bbox

    def xy(lon, lat):
        return ((merc_x(lon) - xmin) / (xmax - xmin) * PIXELS,
                (ymax - merc_y(lat)) / (ymax - ymin) * PIXELS)

    shapes = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
    for poly in shapes:
        painter.polygon([xy(x, y) for x, y in poly.exterior.coords], fill=255)
        for hole in poly.interiors:
            painter.polygon([xy(x, y) for x, y in hole.coords], fill=0)
    return np.asarray(canvas) > 127


def detect_grass(natural: Image.Image, falsecolor: Image.Image | None, sensitivity: int) -> np.ndarray:
    """Experimental vegetation/texture segmentation; not semantic grass AI."""
    rgb = np.asarray(natural, dtype=np.float32)
    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
    gray = (0.299 * r + 0.587 * g + 0.114 * b)
    mean = uniform_filter(gray, size=9)
    variance = np.maximum(0, uniform_filter(gray * gray, size=9) - mean * mean)
    texture = np.sqrt(variance)
    t = max(0, min(100, sensitivity)) / 100
    texture_cap = 15 + t * 27
    brightness_ok = (gray > 37 - t * 10) & (gray < 244)
    if falsecolor is not None:
        f = np.asarray(falsecolor, dtype=np.float32)
        nir = f[:, :, 0]
        red = f[:, :, 1]
        ndvi_proxy = (nir - red) / (nir + red + 1e-6)
        vegetation = (ndvi_proxy > 0.18 - t * 0.14) & (nir > 65 - t * 14)
    else:
        # If no false-color service: visible-green heuristic only.
        vegetation = (g > r * (1.08 - t * .28)) & (g > b * (1.05 - t * .25)) & (g > 43)
    # Smooth grass is less textured than most tree canopies. Not a proof of lawn.
    mask = vegetation & (texture < texture_cap) & brightness_ok
    mask = binary_opening(mask, structure=np.ones((3, 3), dtype=bool))
    mask = binary_closing(mask, structure=np.ones((4, 4), dtype=bool))
    return mask


def png_overlay(grass: np.ndarray) -> str:
    arr = np.zeros((PIXELS, PIXELS, 4), dtype=np.uint8)
    arr[grass, 0] = 38
    arr[grass, 1] = 240
    arr[grass, 2] = 117
    arr[grass, 3] = 115
    edge = grass & ~binary_opening(grass, structure=np.ones((5, 5), dtype=bool))
    arr[edge, 3] = 180
    output = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(output, format="PNG")
    return "data:image/png;base64," + base64.b64encode(output.getvalue()).decode()


def jpg_image(img: Image.Image) -> str:
    out = io.BytesIO()
    img.save(out, "JPEG", quality=89)
    return "data:image/jpeg;base64," + base64.b64encode(out.getvalue()).decode()


@app.get("/")
def home():
    return send_from_directory("static", "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory("static", "manifest.webmanifest")


@app.post("/api/measure")
def measure():
    payload = request.get_json(silent=True) or {}
    address = str(payload.get("address", "")).strip()
    if len(address) < 8 or len(address) > 220:
        return jsonify({"error": "Enter a full street address, city, and state."}), 400
    try:
        sensitivity = int(payload.get("sensitivity", 55))
        radius = int(payload.get("radius_m", 37))
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid measurement settings."}), 400
    sensitivity = max(0, min(sensitivity, 100))
    radius = max(15, min(radius, 150))
    try:
        location = geocode(address)
        lon, lat = location["lon"], location["lat"]
        geom, scope = None, "search-zone"
        custom = payload.get("custom_boundary")
        if custom is not None:
            geom = shape(custom)
            if not geom.is_valid:
                geom = geom.buffer(0)
            if geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
                raise ValueError("Draw a valid property boundary to remeasure.")
            if geom.area > .0003 or geom.distance(Point(lon, lat)) > 0.03:
                raise ValueError("The drawn boundary is too large or too far from the address.")
            scope = "user-drawn"
        elif location["state"] == "KY":
            geom = query_boone_parcel(location["label"], lon, lat)
            if geom is not None:
                scope = "matched-parcel"
        # An address geocoder point is often on a road; a circle is NOT a parcel.
        if geom is None:
            x, y = merc_x(lon), merc_y(lat)
            # Buffer in local true-ground meters, not distorted Mercator meters.
            rad = radius / max(math.cos(math.radians(lat)), .1)
            # Build a local-ground-distance circle around the interpolated
            # geocoder point. This must NEVER be represented as a parcel.
            geom = transform(lambda xx, yy, z=None: (inv_x(xx), inv_y(yy)),
                             Point(x, y).buffer(rad, resolution=80))
        bbox = bounds_for(geom if scope != "search-zone" else None, lat, lon, radius)
        natural = export_naip(bbox, "NaturalColor")
        try:
            falsecolor = export_naip(bbox, "FalseColorComposite")
        except DataUnavailable:
            falsecolor = None
        full_mask = detect_grass(natural, falsecolor, sensitivity)
        roi = geometry_mask(geom, bbox)
        grass = full_mask & roi
        xmin, ymin, xmax, ymax = bbox
        local_cos = math.cos(math.radians(lat))
        pixel_ground_area = ((xmax-xmin) / PIXELS) * ((ymax-ymin) / PIXELS) * local_cos * local_cos
        sqft = float(grass.sum()) * pixel_ground_area * METERS_TO_FEET2
        roi_sqft = float(roi.sum()) * pixel_ground_area * METERS_TO_FEET2
        result = {
            "address": location["label"], "location": {"lat": lat, "lon": lon},
            "sqft": round(sqft), "scope_sqft": round(roi_sqft),
            "scope": scope, "falsecolor_used": falsecolor is not None,
            "sensitivity": sensitivity,
            "bounds": [[inv_y(ymin), inv_x(xmin)], [inv_y(ymax), inv_x(xmax)]],
            "aerial_image": jpg_image(natural), "grass_overlay": png_overlay(grass),
            "boundary": mapping(geom.simplify(0.0000008, preserve_topology=True)),
            "imagery_attribution": "USGS / USDA / The National Map — NAIP aerial imagery",
            "warnings": ["Automatic lawn classification is experimental. Trees, gardens, and shadows may be misidentified."],
        }
        if scope == "search-zone":
            result["warnings"].insert(0, "No matching property parcel was confirmed. This is a circular SEARCH ZONE, not the property's actual lawn area. Draw a property boundary before using the result for a quote.")
        if falsecolor is None:
            result["warnings"].append("False-color vegetation imagery unavailable; used a less reliable visible-color estimate.")
        if ((xmax-xmin) * local_cos / PIXELS) > 1.5:
            result["warnings"].append("Large property: imagery sampling is coarse and may miss narrow grass strips.")
        return jsonify(result)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 422
    except DataUnavailable as exc:
        return jsonify({"error": str(exc)}), 503
    except Exception:
        app.logger.exception("Unexpected measurement failure")
        return jsonify({"error": "Unexpected measurement error. Try a different address or retry."}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
