"""Quick dependency-light geometry/detector smoke test.

Uses a tiny Flask stub so tests can run with GIS/scientific dependencies even
in a build environment where installing Flask/requests against PyPI is blocked.
"""
import importlib.util
import math
import sys
import types

import numpy as np
from PIL import Image
from shapely.geometry import Polygon


class App:
    def __init__(self, *a, **kw):
        self.json = types.SimpleNamespace(sort_keys=True)
    def get(self, *a):
        return lambda fn: fn
    def post(self, *a):
        return lambda fn: fn
    def run(self, **kw):
        pass


sys.modules['flask'] = types.SimpleNamespace(Flask=App, jsonify=lambda x: x,
                                             request=None, send_from_directory=None)
spec=importlib.util.spec_from_file_location('lm', '/mnt/data/LawnMeasure/app.py')
lm=importlib.util.module_from_spec(spec); spec.loader.exec_module(lm)

lat, lon = 39.0, -84.6
assert abs(lm.inv_x(lm.merc_x(lon))-lon) < 1e-9
assert abs(lm.inv_y(lm.merc_y(lat))-lat) < 1e-9

# ~30x40 meter test parcel, with one small excluded hole (treehouse).
x, y = lm.merc_x(lon), lm.merc_y(lat)
cos=math.cos(math.radians(lat))
def ll(dx,dy):
    return lm.inv_x(x+dx/cos), lm.inv_y(y+dy/cos)
coords=[ll(-15,-20),ll(15,-20),ll(15,20),ll(-15,20)]
poly=Polygon(coords)
b=lm.bounds_for(poly,lat,lon,37)
mask=lm.geometry_mask(poly,b)
px_area=(b[2]-b[0])*(b[3]-b[1])*cos*cos/lm.PIXELS**2
actual_sqft=mask.sum()*px_area*lm.METERS_TO_FEET2
assert 12200 < actual_sqft < 13700, actual_sqft

rgb=np.zeros((lm.PIXELS,lm.PIXELS,3),dtype=np.uint8)
rgb[:]=[57,139,57]
false=np.zeros_like(rgb)
false[:]=[195,75,110]  # clearly NIR > red: vegetation
natural=Image.fromarray(rgb)
fc=Image.fromarray(false)
green=lm.detect_grass(natural,fc,55)
assert np.mean(green[30:-30,30:-30])>0.95
assert lm.png_overlay(green).startswith('data:image/png;base64,')
assert lm.jpg_image(natural).startswith('data:image/jpeg;base64,')

badfalse=np.zeros_like(false);badfalse[:]=[80,180,80]
notgrass=lm.detect_grass(natural,Image.fromarray(badfalse),55)
assert np.mean(notgrass)<0.005
print('PASS: geometry, projected area, vegetation segmentation, image encode')

# Exercise the actual request-to-response pipeline using synthetic imagery,
# without making network requests or claiming the remote services were tested.
lm.request=types.SimpleNamespace(get_json=lambda silent=True: {
    'address':'100 TEST ST, FLORENCE, KY 41042',
    'sensitivity':55, 'radius_m':37,
})
lm.geocode=lambda address:{'lon':lon,'lat':lat,'label':address,'state':'KY'}
lm.query_boone_parcel=lambda addr,lng,latitude: poly
lm.export_naip=lambda bbox,fn: natural if fn=='NaturalColor' else fc
result=lm.measure()
assert isinstance(result,dict)
assert result['scope']=='matched-parcel'
assert 12000 < result['sqft'] < 14000
assert result['sqft'] <= result['scope_sqft']
assert result['boundary']['type']=='Polygon'
assert result['aerial_image'].startswith('data:image/jpeg;base64,')

lm.query_boone_parcel=lambda addr,lng,latitude: None
fallback=lm.measure()
assert fallback['scope']=='search-zone'
assert any('not the property' in x.lower() for x in fallback['warnings'])
print('PASS: complete synthetic API measurement + parcel-not-found warning')
