# LawnMeasure · address-based lawn area estimator

A working **Flask web app/PWA prototype** for U.S. addresses, intended as a quoting helper for lawn-care operators. Enter a street address, show the real USGS/USDA NAIP aerial photograph, and **automatically estimate** grass-like square footage within a geographic area. Click **Draw property** to trace an actual lot boundary; click **Draw lawn area** to replace the automatic value by polygons you draw.

**Important:** This is **not** a production-grade lawn detector. It uses a reproducible free vegetation/texture heuristic, *not* a trained AI model, and can confuse trees, shrubs, gardens, shadows, and dormant grass. Do not use its output without visual verification. "Automatic estimate" means the mask is calculated automatically, not that the correct lawn is guaranteed. A matched lot outline is available automatically for **Boone County, Kentucky** when the county GIS site-address field matches. Other U.S. addresses use a clearly labeled **circular search zone**, which is *not* the property's boundary; draw the property first. This is not a survey tool.

## What the app already does

- Street address search via **U.S. Census geocoding API** (no API key).
- Retrieves **actual government NAIP aerial imagery** from USGS (no API key).
- Tries official **Boone County, Kentucky parcel outlines** when the returned address matches a county GIS record.
- Segments vegetation using NAIP false-color imagery and a texture heuristic; falls back to visible-green segmentation when false-color imagery is unavailable.
- Counts detected pixels *inside the selected polygon*, converting projected pixel area to square feet with latitude scale correction.
- Shows the aerial photo, colored grass detection overlay, result, perimeter/lot footprint, detection sensitivity and warnings.
- Lets you **draw and remeasure a property boundary** when parcel data is missing or inaccurate.
- Lets you **draw one or more lawn zones** for a direct manual square-footage override.
- Save the aerial image with the **automatic** green overlay as a PNG.
- Mobile-responsive, with a basic web-app manifest/icons; works from an iPhone browser when publicly hosted over HTTPS.

## Run locally on Windows / macOS / Linux

Install **Python 3.11+**. In a terminal in this folder:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000** in a browser. Internet access is required to load Leaflet JS and retrieve government services. For reproducible deployments pin versions and vendor Leaflet/Leaflet.draw assets locally rather than loading them from the CDN.

## Hosting / iPhone

You must host the Python backend; uploading only `index.html` to a static host will not work.

A simple host that supports Python/Flask (such as a small VM or Python web service) can run:

```bash
gunicorn -w 2 -b 0.0.0.0:${PORT:-8000} app:app --timeout 120
```

Set up a **HTTPS** domain for real usage, then open the site in Safari on an iPhone and use **Share → Add to Home Screen**. This gives a home-screen web app, **not an Apple App Store binary**. To submit to the App Store later, create an iOS native wrapper (for example Capacitor) with a backend HTTPS URL, build/sign it with Xcode on a Mac, test, and submit through App Store Connect. Apple Developer Program membership is needed for distribution. Native binaries are not included in this ZIP.

## Data sources / licensing / limitations

1. **Flask** (BSD-3-Clause); NumPy (BSD-3-Clause); SciPy (BSD-3-Clause); Pillow (HPND); Shapely (BSD-3-Clause); requests (Apache-2.0); Leaflet (BSD-2-Clause); Leaflet.draw (MIT). Consult license files from upstream on redistribution; the dependencies are not bundled into the ZIP.
2. **USGS/USDA NAIP aerial imagery**: sourced from the U.S. National Map ImageServer. Government NAIP imagery is publicly downloadable, but check data-source notices and USGS service usage limits for sustained/commercial workloads. Attribution appears in the app. Endpoint: `https://imagery.nationalmap.gov/arcgis/rest/services/USGSNAIPImagery/ImageServer`.
3. **Census Geocoder**: `https://geocoding.geo.census.gov/geocoder/locations/onelineaddress`. U.S. address ranges may place the pin **on the street**, not at the house center; a geocoded point is not a boundary.
4. **Boone County GIS parcels**: `https://secure.boonecountygis.com/server/rest/services/ParcelLayers/MapServer/32`. © Boone County GIS Services Division / Boone County Planning Commission. Public visibility is **not equivalent to an unrestricted commercial reuse license**. Check with the county before commercial redistribution or heavy usage. Only explicit, close address matches are used; nearest-neighbor guessing is deliberately avoided.
5. Coverage: USGS NAIP generally covers the contiguous United States. Image vintages and resolution vary. The service may throttle or be unavailable; this app will return an error rather than making up a number. No paid providers and no API keys are included.
6. Color-based masking is an experimental **classification heuristic**. It cannot reliably separate turfgrass from trees or landscaping, and can under-detect dormant or brown grass. A higher-quality system needs a trained semantic segmentation model, building/driveway exclusion, verified parcels for every county, training data, and independent validation on real properties.
7. The app does not store user addresses or customer records itself. Requests are sent to government services; your own hosting provider may keep HTTP logs. Evaluate privacy policy and legal obligations before public launch.

## Project layout

```
app.py                  Flask API, geocoding, parcel lookup, image retrieval, detection
static/index.html       responsive Leaflet viewer and polygon tools
static/manifest.webmanifest
static/icon-*.png
requirements.txt
README.md
```

## API

`POST /api/measure` using JSON:

```json
{
  "address": "[complete US street address]",
  "sensitivity": 55,
  "radius_m": 37
}
```

For user-drawn parcel boundaries, include `custom_boundary` as a valid WGS84 GeoJSON **Polygon**/MultiPolygon geometry (coordinates `[longitude, latitude]`). The response includes rounded `sqft`, `scope_sqft`, `scope`, `bounds` and two data-image URLs. `scope = search-zone` is **not** a verified property boundary. Errors return JSON and appropriate HTTP status codes.

## Before offering this as a commercial service

- Arrange lawful parcel-boundary coverage for desired markets and verify official licensing, availability, and request limits.
- Add authenticated user accounts and per-business data isolation **only if you decide to productize**. The current version deliberately has no customer database, billing, or pricing calculations.
- Improve imagery confidence detection, train a lawn-vs-tree classifier, obtain newer localized aerial imagery where available, validate with ground-truth measurements, and add uncertainty scores.
- Add request caching/rate-limits, monitoring, security hardening, pinned software versions, service-failure retries, health checks, and data-license review.

## Simplified live preview deployment on Render

The included `render.yaml` configures a free-tier Python web service. To obtain
an actual shareable HTTPS URL, upload the contents of this directory to a new
GitHub repository, then create a Render Blueprint from that repository, or a
Render Python Web Service using the documented commands. Render will assign
an `https://<your-service>.onrender.com` URL after deployment succeeds. This
project has **not** been uploaded or deployed by ChatGPT; no public demo URL
exists until a hosting account publishes it. Free-tier services may sleep when
idle and have usage limits. Public deployment can attract expensive/excessive
queries to government imagery providers; use for limited evaluation only.
